package com.example.lms.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.lms.entities.User;

public interface UserRepository  extends JpaRepository<User,String>{
    
}
